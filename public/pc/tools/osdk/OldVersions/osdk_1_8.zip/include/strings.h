/* strings.h */

/* This is just a link to string.h */

#include <string.h>

/* end of file strings.h */

