/* oric.h */

#ifndef _ORIC_

#define _ORIC_

#ifdef __OLD__

#include <old/oric.h>

#else

#include <sys/oric.h>

#endif /* __OLD__ */


#endif /* _ORIC_ */

/* end of file oric.h */

