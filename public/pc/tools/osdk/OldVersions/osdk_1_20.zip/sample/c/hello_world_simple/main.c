//
// This is the standard "HELLO WORLD" sample
//

#include <lib.h>
#include <sys/sound.h>

void main()
{
	printf("Hello World !\n");
}
